from flask import Flask, render_template, request, redirect, session, url_for
import os

app = Flask(__name__)
app.secret_key = "dummy"
FILE_DIRECTORY = r"C:\Users\ANAS\Desktop\Files"
USER_CREDENTIALS = {
    "heyanas31": "anas1122"
}

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user" in session:
        return redirect(url_for("home"))

    error = ""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username in USER_CREDENTIALS and USER_CREDENTIALS[username] == password:
            session["user"] = username
            return redirect(url_for("home"))
        else:
            error = "Invalid username or password."
    return render_template("index.html", login=True, error=error)

@app.route("/", methods=["GET", "POST"])
def home():
    if "user" not in session:
        return redirect(url_for("login"))

    recommendations = []
    if request.method == "POST" and "movie" in request.form:
        usermovie = request.form["movie"].strip()
        with open("Moviename.txt", "w") as f:
            f.write(usermovie)
        filename = usermovie + ".txt"
        movie_path = os.path.join(FILE_DIRECTORY, filename)
        try:
            with open(movie_path, "r") as file:
                recommendations = [line.strip() for line in file if line.strip()]
        except FileNotFoundError:
            recommendations = [f"No recommendation file found for '{usermovie}'."]
    
    return render_template("index.html", login=False, recommendations=recommendations)

@app.route("/save", methods=["POST"])
def WatchLaterMovies():
    watchlatermovies = request.form.getlist("selected")
    with open("WatchLater.txt", "w") as f:
        f.write("WATCH LATER LIST\n")
        for movie in watchlatermovies:
            f.write(movie + "\n")
    return redirect("/")

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/login")

if __name__ == "__main__":
    app.run(debug=True)
